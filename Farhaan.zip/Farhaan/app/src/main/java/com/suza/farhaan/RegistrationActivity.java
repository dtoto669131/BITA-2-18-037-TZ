package com.suza.farhaan;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class RegistrationActivity extends AppCompatActivity {
    EditText userEditText, passEditText;
    Button registerButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);

        registerButton = findViewById(R.id.register_btn);
        userEditText = findViewById(R.id.username_text);
        passEditText = findViewById(R.id.password_text);

        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String username = userEditText.getText().toString();
                String password = passEditText.getText().toString();

                /**
                 * Save to DB
                 */
                DB db = new DB(RegistrationActivity.this);
                db.registerUser(username, password);

                Toast.makeText(getApplicationContext(), "Registered successfully.", Toast.LENGTH_SHORT).show();
            }
        });
    }
}