package com.suza.farhaan;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DB extends SQLiteOpenHelper {
    public DB(Context context) {
        super(context, "myDatabase", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String create = "CREATE TABLE users (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT, password TEXT)";
        db.execSQL(create);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        db.execSQL("DROP TABLE IF EXISTS users");
        onCreate(db);
    }

    /**
     * Insert User to database
     * @param username
     * @param password
     */
    public void registerUser(String username, String password) {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues contentValues = new ContentValues();
        contentValues.put("username", username);
        contentValues.put("password", password);

        db.insert("users", null, contentValues);
        db.close();
    }

    /**
     * Login
     * @param username
     * @param password
     * @return
     */
    public boolean loginUser(String username, String password) {
        SQLiteDatabase db = getWritableDatabase();
        String sql = "SELECT id FROM users WHERE username = '"+username+"' AND password = '"+password+"'";
        Cursor cursor = db.rawQuery(sql, null);

        if (cursor.moveToNext()) return true;
        else return false;
    }
}
