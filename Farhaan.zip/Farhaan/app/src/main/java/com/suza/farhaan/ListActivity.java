package com.suza.farhaan;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class ListActivity extends AppCompatActivity {
    TextView welcomeText;
    Button logoutButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);

        welcomeText = findViewById(R.id.welcome_text);
        logoutButton = findViewById(R.id.logout_btn);

        final SharedPreferences preferences = getSharedPreferences("myData", MODE_PRIVATE);
        String username = preferences.getString("username", "");

        if (username == null || username.equals("")) {
            redirectBackToMainPageIfUserNotLoginOrLogoutButtonClicked();
        } else {
            welcomeText.setText("Welcome, " + username);
        }

        /**
         * Logout
         */
        logoutButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SharedPreferences.Editor editor = preferences.edit();
                editor.clear();
                editor.commit();

                redirectBackToMainPageIfUserNotLoginOrLogoutButtonClicked();
            }
        });
    }

    private void redirectBackToMainPageIfUserNotLoginOrLogoutButtonClicked() {
        Intent intent = new Intent(ListActivity.this, MainActivity.class);
        startActivity(intent);
    }
}