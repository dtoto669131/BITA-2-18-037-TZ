package com.suza.farhaan;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {
    EditText userEditText, passEditText;
    Button loginButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        loginButton = findViewById(R.id.log_btn);
        userEditText = findViewById(R.id.username_login_text);
        passEditText = findViewById(R.id.password_login_text);

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String username = userEditText.getText().toString();
                String password = passEditText.getText().toString();

                DB db = new DB(LoginActivity.this);
                boolean isValid = db.loginUser(username, password);

                if (isValid) {
                    /**
                     * SharedPreferences
                     */
                    SharedPreferences preferences = getSharedPreferences("myData", MODE_PRIVATE);
                    SharedPreferences.Editor editor = preferences.edit();
                    editor.putString("username", username);
                    editor.commit();

                    Intent intent = new Intent(LoginActivity.this, ListActivity.class);
                    startActivity(intent);

                } else {
                    Toast.makeText(getApplicationContext(), "Incorrect Username/Password", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}